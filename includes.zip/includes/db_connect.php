<?php
// db_connect.php: use MySQLi to connect to the database
$servername = "localhost";
$username = "root";
$password = ""; // your DB password
$dbname = "pharmacy";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>